<!DOCTYPE html>
<html>
<head>
	<title>Web Potensi Sidoarjo</title>



<div class="row clearfix" style="background-color:white">
  	<?php include 'nav.php';?>
	
	<div class="col-lg-12">
	
	</div>
	<div class="">
		<div class="col-md-12">
			<?php include 'slider.php';?>
		</div>
	
			<?php 
			 
			?>
			
	</div>
		<div class="col-md-12">
		<br>

		
		<div class="col-md-4">
			
		</div>
	</div>
	</div>
</div>
</div>	
</body>
</html>