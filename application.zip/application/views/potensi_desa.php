
  <title>
   <?php echo($title);?>  
  
  </title>
   </div>
   <div class="col-md-8">
     <div class="panel panel-default">
       <div class="panel-heading">
         <h3>Potensi Sidoarjo - <?php echo $tempat;?></h3>
       </div>
       <?php echo ("Perikanan, industri dan jasa merupakan sektor perekonomian utama Sidoarjo. Selat Madura di sebelah Timur merupakan daerah penghasil perikanan, di antaranya Ikan, Udang, dan Kepiting. Logo Kabupaten menunjukkan bahwa Udang dan Bandeng merupakan komoditas perikanan yang utama kota ini. Sidoarjo dikenal pula dengan sebutan Kota Petis. ");?>
       </div>
     </div>
   </div> 
  </div>
