	<title>
   <?php echo("Web Potensi Sidoarjo");?> 
  </title>
  
     <div class="col-md-12">
       <div class="panel panel-default">
          <div class="panel-heading">
          <h3>Data Desa</h3>
          </div>
           <div class="panel-body">
              <table class="table table-striped table-bordered">
                <tr>
                  <td>Nama Desa</td><td><?php echo $tempat;?></td>
                </tr>
                <tr>
                  <td>Jumlah Penduduk</td><td><?php echo count($all->result());?> Orang </td>
                </tr>
                <tr>
                   <td>Luas Wilayah</td><td><?php echo $luas;?> 602,1 km² </td>
                </tr>
                 <tr>
                   <td>Ketinggian</td><td><?php echo $ketinggian;?> DPL</td>
                </tr>
                  <tr>
                   <td>Keadaan Permukaan</td><td><?php echo $keadaan_permukaan;?></td>
                </tr>
              </table>
           </div>   
       </div>
     </div>
   </div>
   <div class="col-md-8">
     <div class="panel panel-default">
       <div class="panel-heading">
         <h3>Data Penduduk - <?php echo ("2.266.533 jiwa");?></h3>
       </div>
       <div class="panel-body">
         <table class="table table-bordered table-striped">
          <tr>
         
          </table>          
       </div>
     </div>
   </div> 
  </div>
