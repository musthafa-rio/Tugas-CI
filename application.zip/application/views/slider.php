<div class="carousel slide" id="carousel-41611">
				<ol class="carousel-indicators">
					<li class="active" data-slide-to="0" data-target="#carousel-41611">
					</li>
					<li data-slide-to="1" data-target="#carousel-41611">
					</li>
					<li data-slide-to="2" data-target="#carousel-41611">
					</li>
				</ol>
				<div class="carousel-inner">
				
					<div class="item active" >
						<img width="100%" alt="" src="<?=base_url("src/img/2.png");?>" />
						<div class="carousel-caption">
							<h4>
								
							</h4>
							<p>
										
							</p>
						</div>
					</div>
					<div class="item">
					<img width="100%" alt="" src="<?=base_url("src/img/3.png");?>" />
						<div class="carousel-caption">
							<h4>
							
							</h4>
							<p>
									
							</p>
						</div>
					</div>
						<div class="item ">
						<img width="100%" alt="" src="<?=base_url("src/img/1.png");?>" />
						<div class="carousel-caption">
							<h4>
								<!-- Disini Bisa Text-->
							</h4>
							<p>
									</p>
						</div>
					</div>
				</div> <a class="left carousel-control" href="#carousel-41611" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a> <a class="right carousel-control" href="#carousel-41611" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
			</div>