<div>
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>src/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>src/css/bootstrap.css.map">
	<script type="text/javascript" src="<?php echo base_url();?>src/js/jquery.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>src/js/bootstrap.min.js"></script>	
	
	<script type="text/javascript">
	$(document).ready(function  () {
		$('ul li a').click(function() {
		    $('ul li.active').removeClass('active');
		    $(this).closest('li').addClass('active');
		});
	})
</script>
<style>
body
{background-color:rgba(214, 214, 214, 0.63);}
.clearfix{
    -webkit-box-shadow: 3px 4px 22px -8px rgba(0,0,0,0.75);
-moz-box-shadow: 3px 4px 22px -8px rgba(0,0,0,0.75);
box-shadow: 3px 4px 22px -8px rgba(0,0,0,0.75);
}
</style>
</div>