<style>
    .foot{
       
    }
    a.foot{
        color:white;
    }
</style>


