<div class=''>
	<nav class="navbar navbar-default navbar-static-top " role="navigation">
				<div class="navbar-header">
					 <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button> 
					 <a class="navbar-brand" href="<?php echo base_url();?>"><i class="glyphicon glyphicon-home"></i></a>
				</div>
				
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<li>
							<a href="<?php echo base_url();?>">Halaman Utama</a>
						</li>
						<li>
							<a href="<?php echo base_url('beranda/data_kependudukan');?>">Data Kependudukan</a>
						</li>
						<li>
							<a href="<?php echo base_url('potensi_desa');?>">Potensi desa</a>
						</li>
						</li>
					</ul>
					<form class="navbar-form navbar-left" method="POST" action="<?php echo site_url('beranda/cari_berita');?>">
				
			</nav>
</div>