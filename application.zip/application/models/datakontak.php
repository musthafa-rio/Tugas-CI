<?php
	
	class Datakontak extends CI_Model
	{
		
		public function all()
		{
			
	
		}
		}

	