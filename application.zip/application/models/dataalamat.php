<?php
	
	class Dataalamat extends CI_Model
	{
		
		public function all()
		{
			$query=$this->db->get('alamat');
			if ($query->num_rows) 
			{
				return $query;	
			}
			else
			{
				return null;
			}
		}
		
	}
	