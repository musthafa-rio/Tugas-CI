<?php 
	class Datapegawai extends CI_Model
	{
		
		public function all()
		{
		}
		
	}