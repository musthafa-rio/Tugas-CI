<?php
	
	class Datalink extends CI_Model
	{
		
		public function all()
		{
			
		}
	}
	